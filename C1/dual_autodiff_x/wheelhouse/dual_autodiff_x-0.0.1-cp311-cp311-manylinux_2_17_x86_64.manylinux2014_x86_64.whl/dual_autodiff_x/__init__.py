from .dual import Dual

__version__ = "0.0.1"
print(f"dual_autodiff_x package version: {__version__}")
